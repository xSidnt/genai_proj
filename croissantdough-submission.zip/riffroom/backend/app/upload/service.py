import json
import subprocess
from pathlib import Path


class MediaProcessingError(RuntimeError):
    pass


class UploadService:
    ALLOWED_EXTENSIONS = {".mp4", ".mov", ".webm"}
    MAX_DURATION_SECONDS = 60
    MAX_FILE_SIZE_BYTES = 100 * 1024 * 1024

    def __init__(self, upload_dir: Path, audio_dir: Path) -> None:
        self.upload_dir = upload_dir
        self.audio_dir = audio_dir
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        self.audio_dir.mkdir(parents=True, exist_ok=True)

    def get_metadata(self, video_path: Path) -> dict:
        command = [
            "ffprobe", "-v", "error", "-select_streams", "v:0",
            "-show_entries",
            "format=duration:stream=width,height,r_frame_rate,avg_frame_rate",
            "-of", "json", str(video_path),
        ]

        try:
            result = subprocess.run(command, capture_output=True, text=True, check=True)
            data = json.loads(result.stdout)
        except FileNotFoundError as error:
            raise MediaProcessingError("ffprobe is not installed") from error
        except subprocess.CalledProcessError as error:
            detail = error.stderr.strip() or "Unable to read video metadata"
            raise MediaProcessingError(detail) from error

        duration = float(data.get("format", {}).get("duration", 0))
        stream = (data.get("streams") or [{}])[0]
        frame_rate = self._parse_fraction(stream.get("avg_frame_rate"))
        if not frame_rate:
            frame_rate = self._parse_fraction(stream.get("r_frame_rate"))

        return {
            "duration_seconds": duration,
            "width": stream.get("width"),
            "height": stream.get("height"),
            "frame_rate": frame_rate,
        }

    def extract_wav(self, video_path: Path, output_path: Path) -> None:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        command = [
            "ffmpeg", "-y", "-v", "error", "-i", str(video_path),
            "-vn", "-ac", "2", "-ar", "44100",
            "-acodec", "pcm_s16le", str(output_path),
        ]

        try:
            subprocess.run(command, capture_output=True, text=True, check=True)
        except FileNotFoundError as error:
            raise MediaProcessingError("ffmpeg is not installed") from error
        except subprocess.CalledProcessError as error:
            detail = error.stderr.strip() or "Unable to extract audio"
            raise MediaProcessingError(detail) from error

    @staticmethod
    def _parse_fraction(value: str | None) -> float | None:
        if not value:
            return None
        try:
            numerator, denominator = value.split("/", 1)
            return float(numerator) / float(denominator)
        except (ValueError, ZeroDivisionError):
            return None
