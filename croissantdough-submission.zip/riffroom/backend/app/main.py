from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.upload import router as upload_router
from app.transcription import router as transcription_router
from app.chat import router as chat_router

app = FastAPI(title="Riffroom API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(upload_router)
app.include_router(transcription_router)
app.include_router(chat_router)


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok"}
